package com.example.baiduyun.constant;

public class Constant {
    public static final String URL = "http://localhost:8080/api/";
}
